"""
CleanCity Copilot -- Municipal Admin Console
Dark, data-dense ops screen for triaging verified civic issues.
"""

import pandas as pd
import streamlit as st

from utils.api_client import get_tickets, update_ticket_status
from utils.mock_data import SEVERITY_COLOR, CATEGORY_ICON
from utils.theme import inject_dark_admin, icon, icon_span, brandbar

st.set_page_config(page_title="CleanCity Admin", page_icon="🛰️", layout="wide")
inject_dark_admin()

# ---------- Sidebar: nav + filters ----------
with st.sidebar:
    brandbar("Admin Console")
    st.markdown('<hr class="cc-divider">', unsafe_allow_html=True)
    nav = st.radio("Navigate", ["Dashboard", "Resolved Tickets", "Settings"], label_visibility="collapsed")
    st.markdown('<hr class="cc-divider">', unsafe_allow_html=True)
    st.markdown(f"**{icon_span('filter', 14)}Filters**", unsafe_allow_html=True)
    f_category = st.selectbox("Category", ["All", "Garbage", "Pothole", "Sewerage"])
    f_severity = st.selectbox("Severity", ["All", "Critical", "High", "Medium", "Low"])
    f_date = st.selectbox("Date range", ["Last 24h", "Last 48h", "Last 7 days", "All time"])

if nav == "Settings":
    st.markdown(f"## {icon_span('gear', 24)}Settings", unsafe_allow_html=True)
    st.info("Backend URL, notification preferences, and team management go here.")
    st.stop()

# ---------- Load data ----------
status_filter = "Resolved" if nav == "Resolved Tickets" else None
tickets = get_tickets(status=status_filter, category=f_category)

df = pd.DataFrame(tickets)
if df.empty:
    st.markdown(f"## {icon_span('grid', 24)}Admin Dashboard", unsafe_allow_html=True)
    st.warning("No tickets found.")
    st.stop()

if f_severity != "All":
    df = df[df["severity"] == f_severity]

hours_map = {"Last 24h": 24, "Last 48h": 48, "Last 7 days": 24 * 7, "All time": None}
hrs = hours_map[f_date]
if hrs is not None:
    cutoff = pd.Timestamp.now() - pd.Timedelta(hours=hrs)
    df = df[pd.to_datetime(df["created_at"]) >= cutoff]

# ---------- Header ----------
header_icon = "grid" if nav == "Dashboard" else "check"
header_title = "Admin Dashboard" if nav == "Dashboard" else "Resolved Tickets"
st.markdown(f"## {icon_span(header_icon, 24)}{header_title}", unsafe_allow_html=True)
st.markdown('<p class="cc-muted" style="margin-top:-8px;">Prioritized civic issues verified by the AI pipeline.</p>', unsafe_allow_html=True)

# ---------- Top metrics ----------
total_open = (df["status"] == "Open").sum()
critical_alerts = ((df["status"] != "Resolved") & (df["severity"] == "Critical")).sum()
resolved_today = (
    (df["status"] == "Resolved")
    & (pd.to_datetime(df["created_at"]).dt.date == pd.Timestamp.now().date())
).sum()

c1, c2, c3 = st.columns(3)
with c1:
    st.markdown(
        f"""<div class="cc-kpi tone-open"><div class="cc-kpi-label">Total open issues</div>
        <div class="cc-kpi-value">{int(total_open)}</div></div>""",
        unsafe_allow_html=True,
    )
with c2:
    st.markdown(
        f"""<div class="cc-kpi tone-alert"><div class="cc-kpi-label">Critical alerts</div>
        <div class="cc-kpi-value">{int(critical_alerts)}</div></div>""",
        unsafe_allow_html=True,
    )
with c3:
    st.markdown(
        f"""<div class="cc-kpi tone-done"><div class="cc-kpi-label">Resolved today</div>
        <div class="cc-kpi-value">{int(resolved_today)}</div></div>""",
        unsafe_allow_html=True,
    )

st.markdown('<hr class="cc-divider">', unsafe_allow_html=True)

# ---------- Map view ----------
st.markdown(f"#### {icon_span('map', 18)}Issue map", unsafe_allow_html=True)
map_df = df.copy()
map_df["color"] = map_df["severity"].apply(
    lambda s: [int(SEVERITY_COLOR[s][i:i + 2], 16) for i in (1, 3, 5)] + [210]
)
st.map(map_df, latitude="lat", longitude="lng", color="color", size=60)
st.markdown(
    f"""<p class="cc-muted" style="font-size:0.82rem;">
    <span style="color:{SEVERITY_COLOR['Critical']}">●</span> Critical &nbsp;
    <span style="color:{SEVERITY_COLOR['High']}">●</span> High &nbsp;
    <span style="color:{SEVERITY_COLOR['Medium']}">●</span> Medium &nbsp;
    <span style="color:{SEVERITY_COLOR['Low']}">●</span> Low</p>""",
    unsafe_allow_html=True,
)

st.markdown('<hr class="cc-divider">', unsafe_allow_html=True)

# ---------- Data table ----------
st.markdown(f"#### {icon_span('ticket', 18)}Tickets", unsafe_allow_html=True)

display_df = df.copy()
display_df["Category"] = display_df["category"]
display_df = display_df.rename(
    columns={
        "ticket_id": "Ticket ID",
        "severity": "Severity",
        "location_name": "Location",
        "status": "Status",
    }
)[["Ticket ID", "Category", "Severity", "Location", "Status"]].sort_values(
    by="Severity", key=lambda s: s.map({"Critical": 0, "High": 1, "Medium": 2, "Low": 3})
)

st.dataframe(display_df, use_container_width=True, hide_index=True)

st.markdown('<hr class="cc-divider">', unsafe_allow_html=True)

# ---------- Expanded ticket detail / action ----------
st.markdown(f"#### {icon_span('link', 18)}Ticket detail", unsafe_allow_html=True)
ticket_ids = df["ticket_id"].tolist()
selected_id = st.selectbox("Select a ticket to view details & take action", ticket_ids)

if selected_id:
    row = df[df["ticket_id"] == selected_id].iloc[0]
    dcol1, dcol2 = st.columns([1, 1.4])

    with dcol1:
        if row.get("image_url"):
            st.image(row["image_url"], caption="Reported photo", use_container_width=True)
        else:
            st.info("Photo will render here once the backend serves uploaded images.")
        st.markdown(f"**Location:** {row['location_name']}")
        st.markdown(f"**Reported:** {pd.to_datetime(row['created_at']).strftime('%d %b %Y, %I:%M %p')}")
        if row.get("duplicate_count", 0) > 0:
            st.markdown(
                f'<p class="cc-muted" style="font-size:0.85rem;">{icon_span("link", 14)}'
                f'Grouped with {int(row["duplicate_count"])} similar report(s) nearby (50m radius, 48h window).</p>',
                unsafe_allow_html=True,
            )

    with dcol2:
        st.markdown(
            f"<span class='cc-mono' style='font-size:0.85rem; color:var(--ink-muted);'>{row['ticket_id']}</span>",
            unsafe_allow_html=True,
        )
        st.markdown(f"### {row['category']}")
        sev = row["severity"]
        st.markdown(
            f"<span class='cc-sev-badge' style='background:{SEVERITY_COLOR[sev]}22; color:{SEVERITY_COLOR[sev]};'>"
            f"{sev} severity</span>",
            unsafe_allow_html=True,
        )
        st.markdown("**AI summary (reasoning)**")
        st.markdown(f'<p class="cc-muted">{row.get("reasoning", "—")}</p>', unsafe_allow_html=True)
        st.markdown(f"**{icon_span('truck', 15)}Recommended action**", unsafe_allow_html=True)
        st.markdown(f'<p class="cc-muted">{row.get("recommended_action", "—")}</p>', unsafe_allow_html=True)
        st.markdown(f"**{icon_span('mic', 15)}Transcribed voice note**", unsafe_allow_html=True)
        st.markdown(f'<p class="cc-muted" style="font-style:italic;">{row.get("transcribed_note", "—")}</p>', unsafe_allow_html=True)

        st.markdown("**Update status**")
        new_status = st.selectbox(
            "Status", ["Open", "In Progress", "Resolved"],
            index=["Open", "In Progress", "Resolved"].index(row["status"]),
            key=f"status_{selected_id}",
            label_visibility="collapsed",
        )
        if st.button("Save status & deploy field team", key=f"save_{selected_id}", type="primary"):
            res = update_ticket_status(selected_id, new_status)
            if res.get("success"):
                st.success(f"Ticket {selected_id} updated to '{new_status}'.")
                if res.get("mock"):
                    st.caption("Demo mode — backend not connected yet.")
                st.rerun()
