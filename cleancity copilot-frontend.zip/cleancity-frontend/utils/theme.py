"""
CleanCity Copilot -- Design System
-----------------------------------
One shared token set + CSS injector for both the Citizen Portal (light,
paper-and-ink civic form) and the Admin Console (dark, data-dense ops
screen). Icons are inline stroke-based SVGs (no emoji) so the product reads
as a designed civic tool rather than a demo.

Import and call `inject(mode)` once near the top of each page, and use
`icon(name, ...)` anywhere a small glyph is needed.
"""

from __future__ import annotations
import streamlit as st

# ---------------------------------------------------------------------------
# Tokens
# ---------------------------------------------------------------------------

LIGHT = {
    "ink": "#182420",
    "ink_muted": "#5B6B63",
    "paper": "#F5F4EE",
    "surface": "#FFFFFF",
    "surface_sunken": "#EFEDE4",
    "border": "#DEDACD",
    "brand": "#0E5C56",
    "brand_strong": "#0A4842",
    "brand_tint": "#E4EFEC",
    "accent": "#B45309",
    "accent_tint": "#F6E9DC",
}

DARK = {
    "ink": "#DCE6E2",
    "ink_muted": "#83978F",
    "paper": "#0A1210",
    "surface": "#0F1B18",
    "surface_raised": "#142420",
    "border": "#1F3530",
    "brand": "#2FBFA8",
    "brand_strong": "#57D6C0",
    "brand_tint": "#12312B",
}

SEVERITY = {
    "Critical": "#DC2626",
    "High": "#EA580C",
    "Medium": "#CA8A04",
    "Low": "#15803D",
}

SEVERITY_DARK = {
    "Critical": "#F87171",
    "High": "#FB923C",
    "Medium": "#FACC15",
    "Low": "#4ADE80",
}

FONT_IMPORT = (
    "https://fonts.googleapis.com/css2?"
    "family=Manrope:wght@500;600;700;800&"
    "family=IBM+Plex+Mono:wght@500;600&display=swap"
)

# ---------------------------------------------------------------------------
# Icons -- inline stroke SVGs, sized/colored via CSS currentColor
# ---------------------------------------------------------------------------

_ICON_PATHS = {
    "camera": '<path d="M4 8h3l1.5-2h7L17 8h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="14" r="3.4"/>',
    "mic": '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0"/><path d="M12 18v3"/><path d="M9 21h6"/>',
    "pin": '<path d="M12 21s-7-6.1-7-11.2A7 7 0 0 1 19 9.8C19 14.9 12 21 12 21z"/><circle cx="12" cy="9.6" r="2.4"/>',
    "upload": '<path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3"/>',
    "grid": '<rect x="3.5" y="3.5" width="7" height="7" rx="1.2"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.2"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.2"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.2"/>',
    "map": '<path d="M9 4 3 6.5v13L9 17l6 2.5 6-2.5v-13L15 6.5 9 4z"/><path d="M9 4v13"/><path d="M15 6.5v13"/>',
    "alert": '<path d="M12 4 2.5 20h19L12 4z"/><path d="M12 10.5v4"/><circle cx="12" cy="17.2" r="0.6" fill="currentColor" stroke="none"/>',
    "check": '<circle cx="12" cy="12" r="8.5"/><path d="M8.3 12.3l2.4 2.4 5-5.2"/>',
    "gear": '<circle cx="12" cy="12" r="3"/><path d="M12 3.5v2.3M12 18.2v2.3M20.5 12h-2.3M5.8 12H3.5M17.8 6.2l-1.6 1.6M7.8 16.2l-1.6 1.6M17.8 17.8l-1.6-1.6M7.8 7.8 6.2 6.2"/>',
    "filter": '<path d="M4 5h16"/><path d="M7 12h10"/><path d="M10 19h4"/>',
    "ticket": '<path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4V8z"/><path d="M14 6v12" stroke-dasharray="2.5 2.5"/>',
    "link": '<path d="M9.5 14.5 14.5 9.5"/><path d="M11 6.5l1.4-1.4a3.6 3.6 0 0 1 5 5L16 11.5"/><path d="M13 17.5l-1.4 1.4a3.6 3.6 0 0 1-5-5L8 12.5"/>',
    "arrow-right": '<path d="M4 12h15"/><path d="M13 6l6 6-6 6"/>',
    "truck": '<rect x="2.5" y="8" width="11" height="8" rx="1"/><path d="M13.5 11h4l3 3v2h-7z"/><circle cx="7" cy="17.5" r="1.6"/><circle cx="17.5" cy="17.5" r="1.6"/>',
}


def icon(name: str, size: int = 16, color: str = "currentColor", stroke: float = 1.9) -> str:
    body = _ICON_PATHS.get(name, "")
    return (
        f'<svg class="cc-icon" width="{size}" height="{size}" viewBox="0 0 24 24" '
        f'fill="none" stroke="{color}" stroke-width="{stroke}" '
        f'stroke-linecap="round" stroke-linejoin="round" '
        f'xmlns="http://www.w3.org/2000/svg">{body}</svg>'
    )


def icon_span(name: str, size: int = 16, color: str = "currentColor") -> str:
    """Icon wrapped so it sits inline with text via flex, vertical-centered."""
    return f'<span class="cc-icon-wrap">{icon(name, size, color)}</span>'


# ---------------------------------------------------------------------------
# CSS injection
# ---------------------------------------------------------------------------

_BASE_CSS = """
<style>
@import url('%(font)s');

:root {
  --ink: %(ink)s;
  --ink-muted: %(ink_muted)s;
  --paper: %(paper)s;
  --surface: %(surface)s;
  --border: %(border)s;
  --brand: %(brand)s;
  --brand-strong: %(brand_strong)s;
  --radius: 12px;
}

html, body, [class*="css"] { font-family: 'Manrope', -apple-system, sans-serif; }

[data-testid="stAppViewContainer"] { background: var(--paper); }
[data-testid="stHeader"] { background: transparent; }
.block-container { padding-top: 2.2rem; padding-bottom: 3rem; max-width: 760px; }

h1, h2, h3 { font-family: 'Manrope', sans-serif; color: var(--ink); letter-spacing: -0.01em; }
p, li, span, label, div { color: var(--ink); }
.cc-muted, .cc-muted * { color: var(--ink-muted) !important; }

hr, [data-testid="stDivider"] { border-color: var(--border) !important; opacity: 1; }

.cc-icon-wrap { display: inline-flex; align-items: center; vertical-align: -3px; margin-right: 6px; }
.cc-icon { display: block; }

/* -- brand mark -------------------------------------------------------- */
.cc-brandbar { display: flex; align-items: center; gap: 10px; margin-bottom: 2px; }
.cc-mark {
  width: 34px; height: 34px; border-radius: 9px; background: var(--brand);
  display: flex; align-items: center; justify-content: center; flex-shrink: 0;
}
.cc-mark svg { color: var(--paper); }
.cc-brandname { font-weight: 800; font-size: 1.28rem; color: var(--ink); line-height: 1.1; }
.cc-brandsub { font-size: 0.8rem; color: var(--ink-muted); letter-spacing: 0.01em; }

/* -- pill / badge -------------------------------------------------------- */
.cc-pill {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 4px 12px; border-radius: 999px; font-size: 0.78rem; font-weight: 700;
  background: var(--brand-tint); color: var(--brand-strong); border: 1px solid transparent;
}

/* -- step rows (form is a genuine sequence) ------------------------------ */
.cc-step { display: flex; gap: 14px; margin: 6px 0 2px 0; }
.cc-step-num {
  flex-shrink: 0; width: 30px; height: 30px; border-radius: 50%%;
  background: var(--surface); border: 1.6px solid var(--brand);
  color: var(--brand-strong); font-weight: 800; font-size: 0.92rem;
  display: flex; align-items: center; justify-content: center;
}
.cc-step-num.done { background: var(--brand); color: var(--paper); border-color: var(--brand); }
.cc-step-line {
  width: 1.6px; background: var(--border); flex: 1; margin: 2px 0 2px 14.2px;
  min-height: 18px;
}
.cc-step-title { font-weight: 700; font-size: 1.02rem; color: var(--ink); margin-bottom: 2px; }
.cc-step-help { font-size: 0.85rem; color: var(--ink-muted); margin-bottom: 10px; }
.cc-step-body { flex: 1; padding-bottom: 6px; }

/* -- buttons -------------------------------------------------------------*/
div.stButton > button, [data-testid="stBaseButton-primary"], [data-testid="stBaseButton-secondary"] {
  border-radius: 9px !important; font-weight: 700 !important; letter-spacing: 0.01em;
  border: 1.4px solid var(--brand) !important;
}
div.stButton > button[kind="primary"], [data-testid="stBaseButton-primary"] {
  background: var(--brand) !important; color: var(--paper) !important;
}
div.stButton > button[kind="primary"]:hover, [data-testid="stBaseButton-primary"]:hover {
  background: var(--brand-strong) !important; border-color: var(--brand-strong) !important;
}
div.stButton > button[kind="secondary"], [data-testid="stBaseButton-secondary"] {
  background: var(--surface) !important; color: var(--brand-strong) !important;
}

/* -- inputs ----------------------------------------------------------------*/
.stTextInput input, .stTextArea textarea, .stSelectbox [data-baseweb="select"] > div {
  border-radius: 9px !important; border-color: var(--border) !important;
  background: var(--surface) !important;
}
.stTextInput input:focus, .stTextArea textarea:focus {
  border-color: var(--brand) !important; box-shadow: 0 0 0 1px var(--brand) !important;
}

[data-testid="stFileUploaderDropzone"], section[data-testid="stFileUploadDropzone"] {
  background: var(--surface) !important; border: 1.6px dashed var(--border) !important;
  border-radius: var(--radius) !important;
}

/* -- callouts ------------------------------------------------------------*/
[data-testid="stAlertContentInfo"], [data-testid="stAlertContentSuccess"],
[data-testid="stAlertContentWarning"], [data-testid="stAlertContentError"] {
  font-size: 0.92rem;
}
[data-testid="stAlert"] { border-radius: var(--radius) !important; }
</style>
"""

_ADMIN_CSS = """
<style>
[data-testid="stAppViewContainer"] { background: %(paper)s; }
[data-testid="stSidebar"] {
  background: %(surface)s; border-right: 1px solid %(border)s;
}
[data-testid="stSidebar"] * { color: %(ink)s !important; }
[data-testid="stSidebar"] .cc-muted, [data-testid="stSidebar"] .cc-muted * { color: %(ink_muted)s !important; }
[data-testid="stAppViewContainer"] h1, [data-testid="stAppViewContainer"] h2,
[data-testid="stAppViewContainer"] h3, [data-testid="stAppViewContainer"] p,
[data-testid="stAppViewContainer"] span, [data-testid="stAppViewContainer"] label,
[data-testid="stAppViewContainer"] div { color: %(ink)s; }
.block-container { max-width: 1180px; padding-top: 1.6rem; }

.cc-mono, .cc-mono * { font-family: 'IBM Plex Mono', monospace !important; }

/* KPI cards -- differentiated by meaning, not identical shadows */
.cc-kpi {
  background: %(surface)s; border: 1px solid %(border)s; border-radius: 10px;
  padding: 14px 16px; display: flex; flex-direction: column; gap: 4px;
}
.cc-kpi.tone-open   { border-left: 3px solid %(brand)s; }
.cc-kpi.tone-alert  { border-left: 3px solid #F87171; }
.cc-kpi.tone-done   { border-left: 3px solid #4ADE80; }
.cc-kpi-label { font-size: 0.78rem; text-transform: none; color: %(ink_muted)s; font-weight: 600; }
.cc-kpi-value { font-family: 'IBM Plex Mono', monospace; font-size: 1.9rem; font-weight: 600; color: %(ink)s; }

/* Sidebar radio -> nav list look */
[data-testid="stSidebar"] .stRadio [role="radiogroup"] { gap: 2px; }
[data-testid="stSidebar"] .stRadio label {
  padding: 7px 10px; border-radius: 8px; width: 100%%;
}

div[data-testid="stMetric"] { background: %(surface)s; border: 1px solid %(border)s; border-radius: 10px; }

[data-testid="stDataFrame"] { border: 1px solid %(border)s; border-radius: 10px; overflow: hidden; }

.stTextInput input, .stSelectbox [data-baseweb="select"] > div {
  background: %(surface)s !important; border-color: %(border)s !important; color: %(ink)s !important;
}

div.stButton > button[kind="primary"], [data-testid="stBaseButton-primary"] {
  background: %(brand)s !important; border-color: %(brand)s !important; color: #06110E !important;
}
div.stButton > button[kind="secondary"], [data-testid="stBaseButton-secondary"] {
  background: %(surface_raised)s !important; border: 1px solid %(border)s !important; color: %(ink)s !important;
}

.cc-sev-badge {
  display: inline-block; padding: 3px 12px; border-radius: 999px; font-weight: 700; font-size: 0.82rem;
}
.cc-divider { height: 1px; background: %(border)s; margin: 1.4rem 0; border: none; }
</style>
"""


def inject_light():
    st.markdown(_BASE_CSS % {"font": FONT_IMPORT, **LIGHT}, unsafe_allow_html=True)


def inject_dark_admin():
    st.markdown(_BASE_CSS % {"font": FONT_IMPORT, **LIGHT}, unsafe_allow_html=True)
    st.markdown(_ADMIN_CSS % DARK, unsafe_allow_html=True)


def brandbar(subtitle: str = "Civic Issue Reporting"):
    st.markdown(
        f"""
        <div class="cc-brandbar">
          <div class="cc-mark">{icon('grid', 18)}</div>
          <div>
            <div class="cc-brandname">CleanCity Copilot</div>
            <div class="cc-brandsub">{subtitle}</div>
          </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
