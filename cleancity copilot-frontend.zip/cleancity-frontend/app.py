"""
CleanCity Copilot -- Citizen Portal
Alibaba Cloud AI Hackathon 2026

Dead-simple, zero-learning-curve flow for citizens to report:
Garbage Accumulation | Potholes / Road Damage | Sewerage Overflow
"""

import streamlit as st
from utils.api_client import submit_report
from utils.theme import inject_light, brandbar, icon, icon_span

st.set_page_config(
    page_title="CleanCity Copilot",
    page_icon="🏙️",
    layout="centered",
)

inject_light()
brandbar("Report a civic issue in minutes")

if "last_ticket" not in st.session_state:
    st.session_state.last_ticket = None

# ---------- Success state (persists after submit) ----------
if st.session_state.last_ticket:
    ticket = st.session_state.last_ticket
    st.markdown(
        f"""
        <div style="background:var(--surface); border:1px solid var(--border);
                    border-left:3px solid var(--brand); border-radius:12px;
                    padding:1.4rem 1.5rem; margin-top:1.4rem;">
          <div style="display:flex; align-items:center; gap:10px; margin-bottom:6px;">
            {icon('check', 22, 'var(--brand-strong)')}
            <span style="font-weight:800; font-size:1.1rem;">Report submitted</span>
          </div>
          <p class="cc-muted" style="margin:0 0 10px 0;">
            The municipal team has been notified and will review it shortly.
          </p>
          <div class="cc-pill">{icon('ticket', 14)} Tracking ID&nbsp;·&nbsp;{ticket['ticket_id']}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    if ticket.get("mock"):
        st.caption("Demo mode — backend not connected yet, this is a mock ticket ID.")
    st.write("")
    if st.button("Submit another report", type="secondary"):
        st.session_state.last_ticket = None
        st.rerun()
    st.stop()

st.write("")
st.markdown(
    '<p class="cc-muted" style="margin-top:-6px;">'
    "Garbage on the street, a broken road, or an overflowing drain — tell us where, "
    "and we'll route it to the right municipal team."
    "</p>",
    unsafe_allow_html=True,
)
st.markdown('<hr class="cc-divider" style="border:none;height:1px;background:var(--border);margin:1.2rem 0;">', unsafe_allow_html=True)

# ---------- Step 1: Photo ----------
st.markdown(
    f"""
    <div class="cc-step">
      <div>
        <div class="cc-step-num">1</div>
        <div class="cc-step-line"></div>
      </div>
      <div class="cc-step-body">
        <div class="cc-step-title">{icon_span('camera', 17)}Photo of the issue</div>
        <div class="cc-step-help">A clear picture helps our system verify and route the report.</div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)
image_file = st.file_uploader(
    "Upload a photo",
    type=["jpg", "jpeg", "png"],
    label_visibility="collapsed",
)
if image_file:
    st.image(image_file, caption="Preview", use_container_width=True)

# ---------- Step 2: Description / voice ----------
st.markdown(
    f"""
    <div class="cc-step">
      <div>
        <div class="cc-step-num">2</div>
        <div class="cc-step-line"></div>
      </div>
      <div class="cc-step-body">
        <div class="cc-step-title">{icon_span('mic', 17)}Describe what's happening</div>
        <div class="cc-step-help">Type a short note, or record a voice note in Urdu / Roman Urdu.</div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)
description = st.text_area(
    "Description",
    placeholder='e.g. "Gali ke nukkad pe kachra jama hai, 2 din se pada hai..."',
    height=80,
    label_visibility="collapsed",
)
audio_file = st.audio_input("Or record a voice note")

# ---------- Step 3: Location ----------
st.markdown(
    f"""
    <div class="cc-step">
      <div>
        <div class="cc-step-num">3</div>
      </div>
      <div class="cc-step-body">
        <div class="cc-step-title">{icon_span('pin', 17)}Where is it</div>
        <div class="cc-step-help">Type the nearest address or landmark.</div>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)
col1, col2 = st.columns([3, 1.3])
with col1:
    address = st.text_input(
        "Address / area",
        placeholder="e.g. Latifabad Unit 9, Hyderabad",
        label_visibility="collapsed",
    )
with col2:
    use_gps = st.button("Use current location", type="secondary", use_container_width=True)

lat, lng = None, None
if use_gps:
    st.info(
        "Live GPS detection needs a small browser helper component "
        "(e.g. `streamlit-geolocation`) — not wired up yet. Please type the address above for now."
    )

st.markdown('<div style="height:0.6rem"></div>', unsafe_allow_html=True)
st.markdown('<hr class="cc-divider" style="border:none;height:1px;background:var(--border);margin:0.4rem 0 1.2rem 0;">', unsafe_allow_html=True)

# ---------- Submit ----------
can_submit = bool(image_file) and bool(address.strip())
if not can_submit:
    st.markdown(
        '<p class="cc-muted" style="font-size:0.85rem;">A photo and an address are required before you can submit.</p>',
        unsafe_allow_html=True,
    )

if st.button("Submit report", disabled=not can_submit, type="primary", use_container_width=True):
    with st.spinner("Submitting your report..."):
        result = submit_report(
            image_file=image_file,
            audio_file=audio_file,
            description=description,
            lat=lat,
            lng=lng,
            address=address,
        )
    if result.get("success"):
        st.session_state.last_ticket = result
        st.rerun()
    else:
        st.error(f"Something went wrong: {result.get('message', 'Please try again.')}")

st.markdown(
    '<p class="cc-muted" style="text-align:center; font-size:0.78rem; margin-top:2rem;">'
    "CleanCity Copilot · Citizen Portal · Alibaba Cloud AI Hackathon 2026"
    "</p>",
    unsafe_allow_html=True,
)
