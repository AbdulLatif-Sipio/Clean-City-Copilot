"""
CleanCity Copilot -- Citizen Portal
Alibaba Cloud AI Hackathon 2026

Dead-simple, zero-learning-curve form for citizens to report:
Garbage Accumulation | Potholes / Road Damage | Sewerage Overflow
"""

import streamlit as st
from utils.api_client import submit_report

st.set_page_config(
    page_title="CleanCity Copilot",
    page_icon="🏙️",
    layout="centered",
)

# ---------- Styling ----------
st.markdown(
    """
    <style>
    .main .block-container { max-width: 640px; padding-top: 2rem; }
    .cc-tagline { color: #5B6B5B; font-size: 1.05rem; margin-top: -0.6rem; }
    .cc-badge {
        display: inline-block; padding: 2px 10px; border-radius: 999px;
        background: #EAF7EE; color: #16A34A; font-size: 0.8rem; font-weight: 600;
    }
    div.stButton > button {
        width: 100%; height: 3rem; font-size: 1.05rem; font-weight: 600;
        border-radius: 10px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------- Header ----------
st.markdown('<span class="cc-badge">🏙️ Civic Reporting</span>', unsafe_allow_html=True)
st.title("CleanCity Copilot")
st.markdown('<p class="cc-tagline">Report civic issues instantly — kachra, gatar, ya tooti hui sarak.</p>', unsafe_allow_html=True)
st.divider()

if "last_ticket" not in st.session_state:
    st.session_state.last_ticket = None

# ---------- Success message (persists after submit) ----------
if st.session_state.last_ticket:
    ticket = st.session_state.last_ticket
    st.success(
        f"✅ **Report submitted!** Tracking ID: **{ticket['ticket_id']}**\n\n"
        f"Municipal team will review it shortly. Save this ID to track status."
    )
    if ticket.get("mock"):
        st.caption("⚠️ Demo mode — backend not connected yet, this is a mock ticket ID.")
    if st.button("Submit another report", type="secondary"):
        st.session_state.last_ticket = None
        st.rerun()
    st.stop()

# ---------- Form ----------
st.subheader("📷 Step 1 — Photo")
image_file = st.file_uploader(
    "Snap or upload a picture of the problem",
    type=["jpg", "jpeg", "png"],
    help="A clear photo of the garbage, pothole, or sewerage overflow.",
)
if image_file:
    st.image(image_file, caption="Preview", use_container_width=True)

st.subheader("🎙️ Step 2 — Voice Note (optional)")
st.caption("Record in Urdu / Roman Urdu — e.g. \"Gali ke nukkad pe kachra jama hai\"")
audio_file = st.audio_input("Record your voice note")

description = st.text_area(
    "Or type a short description instead",
    placeholder="e.g. Gali ke nukkad pe kachra jama hai, 2 din se pada hai...",
    height=80,
)

st.subheader("📍 Step 3 — Location")
col1, col2 = st.columns([3, 1])
with col1:
    address = st.text_input("Address / area", placeholder="e.g. Latifabad Unit 9, Hyderabad")
with col2:
    st.markdown("<div style='height:1.6rem'></div>", unsafe_allow_html=True)
    use_gps = st.button("📡 Use current location")

lat, lng = None, None
if use_gps:
    st.info(
        "GPS auto-detect needs a small JS helper component "
        "(e.g. `streamlit-geolocation`) — wire this up once we add that package. "
        "For now, please type the address above."
    )

st.divider()

# ---------- Submit ----------
can_submit = bool(image_file) and bool(address.strip())
if not can_submit:
    st.caption("⬆️ A photo and an address are required before you can submit.")

if st.button("🚀 Submit Report", disabled=not can_submit, type="primary"):
    with st.spinner("Submitting your report..."):
        result = submit_report(
            image_file=image_file,
            audio_file=audio_file,
            description=description,
            lat=lat,
            lng=lng,
            address=address,
        )
    if result.get("success"):
        st.session_state.last_ticket = result
        st.rerun()
    else:
        st.error(f"Something went wrong: {result.get('message', 'Please try again.')}")

st.divider()
st.caption("CleanCity Copilot · Citizen Portal · Built for Alibaba Cloud AI Hackathon 2026")
