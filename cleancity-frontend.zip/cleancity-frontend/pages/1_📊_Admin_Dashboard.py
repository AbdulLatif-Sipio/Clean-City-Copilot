"""
CleanCity Copilot -- Municipal Admin Dashboard
High data density, easy to read. Cyber-tech inspired minimalist layout.
"""

import pandas as pd
import streamlit as st

from utils.api_client import get_tickets, update_ticket_status
from utils.mock_data import SEVERITY_COLOR, CATEGORY_ICON

st.set_page_config(page_title="CleanCity Admin", page_icon="📊", layout="wide")

st.markdown(
    """
    <style>
    div[data-testid="stMetric"] {
        background: #F3F5F2; border-radius: 12px; padding: 1rem 1rem 0.5rem 1rem;
        border: 1px solid #E5E7E5;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------- Sidebar: nav + filters ----------
with st.sidebar:
    st.markdown("### 🏙️ CleanCity Copilot")
    st.caption("Municipal Admin Console")
    st.divider()
    nav = st.radio("Navigate", ["Dashboard", "Resolved Tickets", "Settings"], label_visibility="collapsed")
    st.divider()
    st.markdown("**Filters**")
    f_category = st.selectbox("Category", ["All", "Garbage", "Pothole", "Sewerage"])
    f_severity = st.selectbox("Severity", ["All", "Critical", "High", "Medium", "Low"])
    f_date = st.selectbox("Date range", ["Last 24h", "Last 48h", "Last 7 days", "All time"])

if nav == "Settings":
    st.title("⚙️ Settings")
    st.info("Backend URL, notification preferences, and team management go here.")
    st.stop()

# ---------- Load data ----------
status_filter = "Resolved" if nav == "Resolved Tickets" else None
tickets = get_tickets(status=status_filter, category=f_category)

df = pd.DataFrame(tickets)
if df.empty:
    st.title("📊 Admin Dashboard")
    st.warning("No tickets found.")
    st.stop()

if f_severity != "All":
    df = df[df["severity"] == f_severity]

hours_map = {"Last 24h": 24, "Last 48h": 48, "Last 7 days": 24 * 7, "All time": None}
hrs = hours_map[f_date]
if hrs is not None:
    cutoff = pd.Timestamp.now() - pd.Timedelta(hours=hrs)
    df = df[pd.to_datetime(df["created_at"]) >= cutoff]

# ---------- Header ----------
st.title("📊 Admin Dashboard" if nav == "Dashboard" else "✅ Resolved Tickets")
st.caption("Prioritized civic issues verified by the AI pipeline")

# ---------- Top metrics ----------
total_open = (df["status"] == "Open").sum()
critical_alerts = ((df["status"] != "Resolved") & (df["severity"] == "Critical")).sum()
resolved_today = (
    (df["status"] == "Resolved")
    & (pd.to_datetime(df["created_at"]).dt.date == pd.Timestamp.now().date())
).sum()

c1, c2, c3 = st.columns(3)
c1.metric("Total Open Issues", int(total_open))
c2.metric("Critical Alerts", int(critical_alerts), delta_color="inverse")
c3.metric("Resolved Today", int(resolved_today))

st.divider()

# ---------- Map view ----------
st.subheader("🗺️ Issue Map")
map_df = df.copy()
map_df["color"] = map_df["severity"].apply(
    lambda s: [int(SEVERITY_COLOR[s][i:i + 2], 16) for i in (1, 3, 5)] + [200]
)
st.map(map_df, latitude="lat", longitude="lng", color="color", size=60)
st.caption("🔴 Critical · 🟠 High · 🟡 Medium · 🟢 Low")

st.divider()

# ---------- Data table ----------
st.subheader("📋 Tickets")

display_df = df.copy()
display_df["Category"] = display_df["category"].apply(lambda c: f"{CATEGORY_ICON.get(c, '')} {c}")
display_df = display_df.rename(
    columns={
        "ticket_id": "Ticket ID",
        "severity": "Severity",
        "location_name": "Location",
        "status": "Status",
    }
)[["Ticket ID", "Category", "Severity", "Location", "Status"]].sort_values(
    by="Severity", key=lambda s: s.map({"Critical": 0, "High": 1, "Medium": 2, "Low": 3})
)

st.dataframe(display_df, use_container_width=True, hide_index=True)

st.divider()

# ---------- Expanded ticket detail / action ----------
st.subheader("🔍 Ticket Detail")
ticket_ids = df["ticket_id"].tolist()
selected_id = st.selectbox("Select a ticket to view details & take action", ticket_ids)

if selected_id:
    row = df[df["ticket_id"] == selected_id].iloc[0]
    dcol1, dcol2 = st.columns([1, 1.4])

    with dcol1:
        if row.get("image_url"):
            st.image(row["image_url"], caption="Reported photo", use_container_width=True)
        else:
            st.info("📷 Photo will render here once the backend serves uploaded images.")
        st.markdown(f"**Location:** {row['location_name']}")
        st.markdown(f"**Reported:** {pd.to_datetime(row['created_at']).strftime('%d %b %Y, %I:%M %p')}")
        if row.get("duplicate_count", 0) > 0:
            st.caption(f"🔗 Grouped with {int(row['duplicate_count'])} similar report(s) nearby (50m radius, 48h window).")

    with dcol2:
        st.markdown(f"### {CATEGORY_ICON.get(row['category'], '')} {row['category']} — {row['ticket_id']}")
        sev = row["severity"]
        st.markdown(
            f"<span style='background:{SEVERITY_COLOR[sev]}22; color:{SEVERITY_COLOR[sev]}; "
            f"padding:3px 12px; border-radius:999px; font-weight:600;'>{sev} severity</span>",
            unsafe_allow_html=True,
        )
        st.markdown("**AI Summary (reasoning):**")
        st.write(row.get("reasoning", "—"))
        st.markdown("**Recommended action:**")
        st.write(row.get("recommended_action", "—"))
        st.markdown("**Transcribed voice note:**")
        st.write(f"_{row.get('transcribed_note', '—')}_")

        st.markdown("**Update status:**")
        new_status = st.selectbox(
            "Status", ["Open", "In Progress", "Resolved"],
            index=["Open", "In Progress", "Resolved"].index(row["status"]),
            key=f"status_{selected_id}",
        )
        if st.button("Save status & deploy field team", key=f"save_{selected_id}", type="primary"):
            res = update_ticket_status(selected_id, new_status)
            if res.get("success"):
                st.success(f"Ticket {selected_id} updated to '{new_status}'.")
                if res.get("mock"):
                    st.caption("⚠️ Demo mode — backend not connected yet.")
                st.rerun()
